import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Encounter{
	private boolean foundSword=false;
	private boolean foundTroll=false;
	
	
	
	public Player run(Player player) throws InterruptedException {
		if(!foundTroll) {
			player=encounterTroll(player);
			return player;
		}else if(!foundSword){
			encounterSword(player);
			return player;
		}
		return player;
		
	}
	
	public Player encounterTroll(Player player) throws InterruptedException {
		this.foundTroll=true;
		System.out.println("You have come across a troll!\n");
		TimeUnit.SECONDS.sleep(2);
		System.out.println("Would you like to teleport or fight?\n");
		Scanner sc= new Scanner(System.in);
		String input=sc.nextLine();
		if (input.equals("fight")) {
			if(!player.getSword()) {
				System.out.println("You take on a troll with your bear hand and it goes the way you would expect...\n");
				TimeUnit.SECONDS.sleep(3);
				System.out.println("You are dead you stupid stupid person.\n");
				player.setAlive(false);
				return player;
			}
			System.out.println("\nyou fight the troll and kill him.\n");
			TimeUnit.SECONDS.sleep(3);
			System.out.println("Sorry, that I didn't write a better description\n");
			TimeUnit.SECONDS.sleep(3);
			System.out.println("I just honestly didn't think you would get this far");
			TimeUnit.SECONDS.sleep(3);
			return player;
		}
		
		if(input.equals("teleport")) {
			if(!player.getTeleport()) {
				System.out.println("Cant you count..");
				TimeUnit.SECONDS.sleep(3);
				System.out.println("You have allready used your teleport\n");
				TimeUnit.SECONDS.sleep(3);
				System.out.println("Remember that time when there was all that magic and you found yourself in a compleatly differnt place\n");
				TimeUnit.SECONDS.sleep(3);
				System.out.println("That was your teleport...\n");
				TimeUnit.SECONDS.sleep(3);
				System.out.println("You are DEAD!!!\n");
				TimeUnit.SECONDS.sleep(2);
				System.out.println("Idiot");
				player.setAlive(false);
				return player;
			}
			System.out.println("Poof, a you are somewhere else\n");
			TimeUnit.SECONDS.sleep(3);
			System.out.println("but you are still in a swamp so big deal.\n");
			TimeUnit.SECONDS.sleep(3);
			player.ranLocation();
			player.useTeleport();
			return player;
		}
		System.out.println("Where did you learn to type?\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("I clearly said that you could fight or teleport.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("If chester was here he would want me to check for bad input\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("but he isn't here\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("you are DEAD!\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("but worse than that, you have wasted my time and yours");
		player.setAlive(false);
		return player;
	}
	
	public Player encounterSword(Player player) throws InterruptedException {
		System.out.println("You have found a sword\n");
		TimeUnit.SECONDS.sleep(2);
		System.out.println("just remember to stick them with the pointy end.\n");
		TimeUnit.SECONDS.sleep(3);
		player.setSword(true);
		this.foundSword=true;
		this.foundTroll=false;
		return player;
	}

}
