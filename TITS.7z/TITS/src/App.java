
public class App {
	public static void main(String[] args) throws InterruptedException {
		TITS tits= new TITS();
		
		tits.start();
		tits.turn();
		if (tits.getPlayer().isAlive()) {
			tits.end();			
		}
		
	}

}
