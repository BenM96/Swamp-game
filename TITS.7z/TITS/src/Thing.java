
public class Thing {
 
	
	private int[] location;
		
		public Thing(int x, int y) {
			int[] location= {x,y};
			this.location=location;
		}
		
		public Thing() {
			this.location=Random.location();
		}
		
		public void ranLocation(){
			this.location=Random.location();
		}
	
		public int[] getLocation() {
			return location;
		}
	
		public void setLocation(int[] location) {
			this.location = location;
		}
		
		public int getX() {
			return location[0];
		}
		
		public int getY() {
			return location[1];
		}
	
}


