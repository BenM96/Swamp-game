import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class TITS {
	private Player player=new Player();
	private Thing treasure= new Thing();
	private Encounter encounter=new Encounter();
	int turns;
	
	
	public void start() throws InterruptedException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 'skip' to skip intro.\n");
		String input=sc.nextLine();
		boolean skip=false;
		if(input.equals("skip")) {
			skip=true;
		}
		
		if (!skip) {
		System.out.println("You are in a swamp and you must find the magical treasure.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("You have a compass that will tell you how far away the treasure is.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("That isnt how compasses work as they clearly give you a direction not the distance so well done to whoever came up with that one.\n");
		TimeUnit.SECONDS.sleep(4);
		System.out.println("The swamp is also infinate for some reason even though that is impossible.\n");
		TimeUnit.SECONDS.sleep(4);
		System.out.println("And dont tell me that it is a magical swamp because we all ready have a jankey compass that doesn't work properly because it is \"magical\"\nand a \"magical\" treasure that somehow gets us out of the swamp.\n");
		TimeUnit.SECONDS.sleep(7);
		System.out.println("At some point it is just lazy writing.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("And that point was a while ago.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("You also have one teleport to get you out of trouble and place you in a random location.");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("How does it work you ask?\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("Drum role please.....\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("by useing quantum particals it breaks down your relative material state and \n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("just jokeing it's magic\n");
		TimeUnit.SECONDS.sleep(3);
		}else {
			System.out.println("Thats cool\n");
			TimeUnit.SECONDS.sleep(3);
			System.out.println("I spent ages writing it but if you dont want to read it that's fine.\n");
			TimeUnit.SECONDS.sleep(4);
		}
		this.player=new Player();
		this.treasure=new Thing();
		while(win()) {
			treasure.ranLocation();
		}
	}
		
	
	
	@SuppressWarnings("resource")
	public void turn() throws InterruptedException {
		int count=0;
		int missType=0;
		while(!win()) {
			boolean goodInput=true;
			count++;
			double xyDelta=Compass.distance(player, treasure);
			System.out.println("you are "+xyDelta+"m away from the tresure\n\n");
			System.out.println("would you like to go north, south east or west?\n");
			Scanner sc= new Scanner(System.in);
			String direction= sc.nextLine();
			System.out.println("\nand how many meters?\n");
			int dis;
			try {
				dis=sc.nextInt();
			}
			catch(Exception e) {
				dis=1;
				direction="asdfasd";
			}
			switch(direction) {
			case "north":
				player.goNorth(dis);
				break;
			
			case "south":
				player.goSouth(dis);
				break;
				
			case "east":
				player.goEast(dis);
				break;
				
			case "west":
				player.goWest(dis);
				break;
				
			default:
				goodInput=false;
				if (missType==0) {
					missType++;
					System.out.println("That wasn't a valid input.\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("Just get it right the next time\n");
					TimeUnit.SECONDS.sleep(3);
					break;
				}
				if(missType==1) {
					missType++;
					System.out.println("That is the second time now.\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("I suppose you think these replys grow on trees.\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("well they dont.\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("It takes time and effort.\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("Just don't do it again.\n");
					break;
				}
				if (missType==2) {
					missType++;
					System.out.println("At first i thought you were just an idiot\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("But now I see you are doing this on puropse\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("Do you like to see me suffer?\n");
					TimeUnit.SECONDS.sleep(3);
					System.out.println("if you waist my time i will waist yours\n");
					TimeUnit.SECONDS.sleep(10);
					System.out.println("didnt likle that did you\n");
					TimeUnit.SECONDS.sleep(3);
					break;
				}
				if (missType==3) {
					missType++;
					System.out.println("I'm just going to start ignoring you now.\n");
					TimeUnit.SECONDS.sleep(3);
					break;
				}
				break;
				
			}
			
			if(Random.encounter()&goodInput) {
				encounter.run(player);
				if(!player.isAlive()) {
					break;
				}
				
			}
			
			}
		this.turns=count;
		
	}
	
	
	
	public void end() throws InterruptedException {
		System.out.println("Well done you did it in "+turns+" moves, you must be really proud of yourself.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("My Nan did it in fewer turns than that.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("I'm not saying you are bad at games. I'm sure you tried really hard.\n");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("I'm just saying you are worse than my Nan\n");
		TimeUnit.SECONDS.sleep(2);
		System.out.println("Who has never played a game before.\n");
		TimeUnit.SECONDS.sleep(2);
		System.out.println("is half blind\n");
		TimeUnit.SECONDS.sleep(2);
		System.out.println("and has no fingers\n");
		TimeUnit.SECONDS.sleep(10);
		System.out.println("You still here? get a life\n");
		
	}
	
	
	public boolean win() {
		if(Compass.distance(player, treasure)==0) {
			return true;
		}else {
			return false;
		}
	}


	
	

	public Player getPlayer() {
		return player;
	}



	public Thing getTreasure() {
		return treasure;
	}




	public void setTreasure(Thing treasure) {
		this.treasure = treasure;
	}
	
	

}
