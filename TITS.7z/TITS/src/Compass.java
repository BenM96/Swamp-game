
abstract public class Compass {
	
	public static double distance (int[] player,int[] treasure){
		int xDelta=player[0]-treasure[0];
		int yDelta=player[1]-treasure[1];
		double xyDelta=Math.sqrt(Math.pow(xDelta, 2)+Math.pow(yDelta, 2));
		return xyDelta;
		
	}
	
	public static double distance (Thing player,Thing treasure){
		int xDelta=player.getX()-treasure.getX();
		int yDelta=player.getY()-treasure.getY();
		double xyDelta=Math.sqrt(Math.pow(xDelta, 2)+Math.pow(yDelta, 2));
		return xyDelta;
		
	}

}
