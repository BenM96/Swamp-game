
public class Player extends Thing{
	private boolean alive;
	private Boolean teleport;
	private Boolean sword;
	Player(){
		super();
		this.alive=true;
		this.teleport=true;
		this.sword=false;
	}
	
	
	
	
	public void goNorth(int dis){
		int[] location=getLocation();
		location[1]=location[1]+dis;
		setLocation(location);
	}
	
	public void goSouth(int dis){
		int[] location=getLocation();
		location[1]=location[1]-dis;
		setLocation(location);
	}
	
	public void goEast(int dis){
		int[] location=getLocation();
		location[0]=location[0]+dis;
		setLocation(location);
	}
	
	public void goWest(int dis){
		int[] location=getLocation();
		location[0]=location[0]-dis;
		setLocation(location);
	}
	
	public void useTeleport() {
		this.teleport=false;
	}
	


	public boolean isAlive() {
		return alive;
	}




	public Boolean getTeleport() {
		return teleport;
	}




	public Boolean getSword() {
		return sword;
	}




	public void setAlive(boolean alive) {
		this.alive = alive;
	}




	public void setTeleport(Boolean teleport) {
		this.teleport = teleport;
	}




	public void setSword(Boolean sword) {
		this.sword = sword;
	}
	
	

}
