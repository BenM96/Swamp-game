
abstract public class Random {
	
	
	
	public static int[] location(){
		int[] xy= new int[2];
		xy[0]= (int) (Math.random()*10);
		xy[1]= (int) (Math.random()*10);		
		return xy;
	}
	
	public static boolean encounter() {
		int chance=(int)(Math.random()*10);
		if (chance>4) {
			return true;
		}
		return false;
	}

}
